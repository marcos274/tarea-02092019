<?php
$lang['scaff_view_records']		= 'Ver registros';
$lang['scaff_create_record']	= 'Crear nuevo registro';
$lang['scaff_add']				= 'Adicionar datos';
$lang['scaff_view']				= 'Ver datos';
$lang['scaff_edit']				= 'Editar';
$lang['scaff_delete']			= 'Eliminar';
$lang['scaff_view_all']			= 'Ver todo';
$lang['scaff_yes']				= 'Sí';
$lang['scaff_no']				= 'No';
$lang['scaff_no_data']			= 'Todavía no existen datos para esta tabla.';
$lang['scaff_del_confirm']		= 'Está seguro de eliminar la siguiente fila:';
?>
