<p><strong>Nombres: </strong> <?php echo $usuario->nombres ?></p>
<p><strong>Apellidos: </strong> <?php echo $usuario->apellidos ?></p>
<p><strong>Teléfono: </strong> <?php echo $usuario->telefono ?></p>
<p><strong>Email: </strong> <?php echo $usuario->email ?></p>
<p><strong>Usuario: </strong> <?php echo $usuario->username ?></p>
<p><strong>Rol: </strong> <?php echo $usuario->rol ?></p>